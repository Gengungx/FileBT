<?php
include 'db_connect.php';


// Lấy dữ liệu từ các bảng lớp
$class1_sql = "SELECT students.student_name, courses.course_name FROM class1
               JOIN students ON class1.student_id = students.student_id
               JOIN courses ON class1.course_id = courses.course_id";
$class1_result = $conn->query($class1_sql);

$class2_sql = "SELECT students.student_name, courses.course_name FROM class2
               JOIN students ON class2.student_id = students.student_id
               JOIN courses ON class2.course_id = courses.course_id";
$class2_result = $conn->query($class2_sql);

$class3_sql = "SELECT students.student_name, courses.course_name FROM class3
               JOIN students ON class3.student_id = students.student_id
               JOIN courses ON class3.course_id = courses.course_id";
$class3_result = $conn->query($class3_sql);

$completed_courses_sql = "SELECT students.student_name, courses.course_name 
                          FROM completed_courses 
                          JOIN students ON completed_courses.student_id = students.student_id 
                          JOIN courses ON completed_courses.course_id = courses.course_id";

$completed_courses_result = $conn->query($completed_courses_sql);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $is_open = $_POST['is_open'] === '1' ? 1 : 0; // Sử dụng 1 và 0 để cập nhật

    $update_sql = "UPDATE system_status SET is_open = $is_open WHERE id = 1";
    
    if ($conn->query($update_sql) === TRUE) {
        echo "<div class='alert alert-success'>Trạng thái hệ thống đã được cập nhật thành công!</div>";
    } else {
        echo "<div class='alert alert-danger'>Lỗi: " . $conn->error . "</div>";
    }
}

// Lấy trạng thái hiện tại
$status_sql = "SELECT is_open FROM system_status WHERE id = 1";
$status_result = $conn->query($status_sql);

$current_status = '0'; // Giá trị mặc định nếu không tìm thấy

if ($status_result && $status_result->num_rows > 0) {
    $status_row = $status_result->fetch_assoc();
    $current_status = $status_row['is_open'] ? '1' : '0';
} else {
    // Nếu không có bản ghi nào, có thể tạo một bản ghi mới
    $conn->query("INSERT INTO system_status (is_open) VALUES (0)");
    $current_status = '0'; // Cập nhật lại trạng thái
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Trang Admin - Quản Lý Hệ Thống</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
<h2>Danh Sách Đăng Ký Lớp Học</h2>

<h3>Lớp 1</h3>
<table class="table table-bordered">
    <thead class="thead-light">
        <tr>
            <th>Sinh Viên</th>
            <th>Môn Học</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($class1_result->num_rows > 0): ?>
            <?php while ($row = $class1_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['student_name']; ?></td>
                    <td><?php echo $row['course_name']; ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="2" class="text-center">Không có sinh viên đăng ký.</td></tr>
        <?php endif; ?>
    </tbody>
</table>


<h3>Lớp 2</h3>
<table class="table table-bordered">
    <thead class="thead-light">
        <tr>
            <th>Sinh Viên</th>
            <th>Môn Học</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($class2_result->num_rows > 0): ?>
            <?php while ($row = $class2_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['student_name']; ?></td>
                    <td><?php echo $row['course_name']; ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="2" class="text-center">Không có sinh viên đăng ký.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<h3>Lớp 3</h3>
<table class="table table-bordered">
    <thead class="thead-light">
        <tr>
            <th>Sinh Viên</th>
            <th>Môn Học</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($class3_result->num_rows > 0): ?>
            <?php while ($row = $class3_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['student_name']; ?></td>
                    <td><?php echo $row['course_name']; ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="2" class="text-center">Không có sinh viên đăng ký.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<h2>Danh Sách Sinh Viên và Môn Học Đã Học</h2>
<table class="table table-bordered">
    <thead class="thead-light">
        <tr>
            <th>Tên Sinh Viên</th>
            <th>Tên Môn Học</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($completed_courses_result->num_rows > 0): ?>
            <?php while($row = $completed_courses_result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['student_name']; ?></td>
                <td><?php echo $row['course_name']; ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="2" class="text-center">Không có môn học đã học.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<a href="logout.php" class="btn btn-danger">Đăng Xuất</a>
</div>

<div class="container mt-4">
    <h2 class="text-center">Quản Lý Trạng Thái Hệ Thống</h2>
    
    <form method="post" action="">
        <div class="form-group">
            <label for="is_open">Trạng Thái Hệ Thống:</label>
            <select id="is_open" name="is_open" class="form-control">
                <option value="1" <?php if ($current_status == '1') echo 'selected'; ?>>Mở</option>
                <option value="0" <?php if ($current_status == '0') echo 'selected'; ?>>Đóng</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary mb-5">Cập Nhật</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

<?php
$conn->close();
?>
