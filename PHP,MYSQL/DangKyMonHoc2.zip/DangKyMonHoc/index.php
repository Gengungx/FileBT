<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];
$student_name = $_SESSION['student_name'];

// Lấy thông tin môn học
$courses_sql = "SELECT * FROM courses";
$courses_result = $conn->query($courses_sql);

// Kiểm tra trạng thái hệ thống
$status_sql = "SELECT is_open FROM system_status WHERE id = 1";
$status_result = $conn->query($status_sql);
$is_system_open = false;

if ($status_result && $status_result->num_rows > 0) {
    $status_row = $status_result->fetch_assoc();
    $is_system_open = $status_row['is_open'] == 1;
}

// Lưu đăng ký môn học
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_id = $_POST['course_id'];

    // Khởi tạo biến lỗi
    $prerequisite_error = '';
    $already_registered = false;
    $course_completed = false;

    // Kiểm tra nếu đã đăng ký môn học
    $check_registered_sql = "SELECT * FROM class1 WHERE student_id = $student_id AND course_id = $course_id
                              UNION
                              SELECT * FROM class2 WHERE student_id = $student_id AND course_id = $course_id
                              UNION
                              SELECT * FROM class3 WHERE student_id = $student_id AND course_id = $course_id";
    $check_result = $conn->query($check_registered_sql);

    if ($check_result->num_rows > 0) {
        $already_registered = true;
    }

    // Kiểm tra xem môn học đã hoàn thành chưa
    $check_completed_sql = "SELECT * FROM completed_courses WHERE student_id = $student_id AND course_id = $course_id";
    $completed_result = $conn->query($check_completed_sql);

    if ($completed_result->num_rows > 0) {
        $course_completed = true;
    }

    // Kiểm tra điều kiện tiên quyết
    if ($course_id == 3) {
        // Môn SQL (ID 3) yêu cầu môn Cơ sở Dữ liệu (ID 2)
        $prereq_sql = "SELECT * FROM completed_courses WHERE student_id = $student_id AND course_id = 2";
        $prereq_result = $conn->query($prereq_sql);

        if ($prereq_result->num_rows == 0) {
            $prerequisite_error = "Bạn chưa học Cơ sở Dữ liệu.";
        }
    } elseif ($course_id == 10) {
        // Môn Điện toán Đám mây (ID 10) yêu cầu môn Trí tuệ Nhân tạo (ID 3)
        $prereq_sql = "SELECT * FROM completed_courses WHERE student_id = $student_id AND course_id = 3";
        $prereq_result = $conn->query($prereq_sql);

        if ($prereq_result->num_rows == 0) {
            $prerequisite_error = "Bạn chưa học Trí tuệ Nhân tạo.";
        }
    } else {
        // Kiểm tra các điều kiện tiên quyết khác nếu có
        $prereq_sql = "SELECT prerequisite_course_id FROM prerequisites WHERE course_id = $course_id";
        $prereq_result = $conn->query($prereq_sql);

        while ($row = $prereq_result->fetch_assoc()) {
            $prereq_course_id = $row['prerequisite_course_id'];
            $completed_sql = "SELECT * FROM completed_courses WHERE student_id = $student_id AND course_id = $prereq_course_id";
            $completed_result = $conn->query($completed_sql);

            if ($completed_result->num_rows == 0) {
                $prerequisite_error = "Bạn chưa học môn tiên quyết.";
                break;
            }
        }
    }

    if ($already_registered) {
        $alert_type = 'warning';
        $alert_message = 'Bạn đã đăng ký môn học này rồi!';
    } elseif ($course_completed) {
        $alert_type = 'info';
        $alert_message = 'Bạn đã hoàn thành môn học này!';
    } elseif ($prerequisite_error) {
        $alert_type = 'danger';
        $alert_message = $prerequisite_error;
    } else {
        // Xác định lớp dựa trên course_id hoặc một số logic khác
        $class_table = '';
        if ($course_id % 3 == 1) {
            $class_table = 'class1';
        } elseif ($course_id % 3 == 2) {
            $class_table = 'class2';
        } else {
            $class_table = 'class3';
        }

        // Thêm vào bảng lớp tương ứng
        $sql = "INSERT INTO $class_table (student_id, course_id) VALUES ($student_id, $course_id)";

        if ($conn->query($sql) === TRUE) {
            $alert_type = 'success';
            $alert_message = 'Đăng ký thành công!';
        } else {
            $alert_type = 'danger';
            $alert_message = 'Lỗi: ' . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng Ký Môn Học</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f5dc; /* Màu nền nâu vàng nhạt */
        }
        .container-sm {
            max-width: 600px; /* Giới hạn chiều rộng */
            background-color: #fff8dc; /* Màu nền trắng ngà */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 20px auto; /* Canh giữa */
        }
        .navbar {
            background-color: #8b4513; /* Màu nâu sẫm */
        }
        .navbar-brand {
            color: #fff; /* Màu chữ trắng */
        }
        .navbar-brand:hover {
            color: #f5f5dc; /* Màu chữ nâu vàng nhạt khi hover */
        }
        .btn-primary {
            background-color: #8b4513; /* Màu nâu sẫm */
            border: none;
        }
        .btn-primary:hover {
            background-color: #a0522d; /* Màu nâu đất khi hover */
        }
        .alert {
            border-radius: 5px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">Hệ Thống Đăng Ký Học</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="main.php">Trang Chủ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php">Đăng ký môn học</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">Hồ Sơ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Đăng Xuất</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container-sm mt-4">
    <h2 class="text-center">Đăng Ký Môn Học</h2>
    <p class="text-center">Chào mừng, <?php echo $student_name; ?>!</p>
    
    <?php if (isset($alert_message)): ?>
        <div class="alert alert-<?php echo $alert_type; ?> mt-3" role="alert">
            <?php echo $alert_message; ?>
        </div>
    <?php endif; ?>

    <form method="post" action="">
        <div class="form-group">
            <label for="course">Chọn Môn Học:</label>
            <select id="course" name="course_id" class="form-control" required>
                <?php while ($row = $courses_result->fetch_assoc()): ?>
                    <option value="<?php echo $row['course_id']; ?>"><?php echo $row['course_name']; ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Đăng Ký</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

<?php
$conn->close();
?>
