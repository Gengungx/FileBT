<?php
include 'db_connect.php';

// Mã hóa mật khẩu
$password = password_hash('123456', PASSWORD_DEFAULT);

// Cập nhật mật khẩu cho 20 sinh viên
for ($i = 1; $i <= 20; $i++) {
    $username = "student" . $i; // Tạo username

    // Cập nhật mật khẩu
    $sql = "UPDATE students SET password='$password' WHERE username='$username'";
    
    if ($conn->query($sql) !== TRUE) {
        echo "Lỗi khi cập nhật mật khẩu cho tài khoản: " . $username . " - " . $conn->error . "<br>";
    }
}

echo "Đã cập nhật mật khẩu cho 20 tài khoản sinh viên thành công!";

// Đóng kết nối
$conn->close();
?>