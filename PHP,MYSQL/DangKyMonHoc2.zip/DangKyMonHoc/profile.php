<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];
$student_name = $_SESSION['student_name'];

// Lấy thông tin sinh viên
$student_sql = "SELECT * FROM students WHERE student_id = $student_id";
$student_result = $conn->query($student_sql);
$student_info = $student_result->fetch_assoc();

// Lấy danh sách các môn học đã hoàn thành
$completed_courses_sql = "SELECT c.course_name FROM completed_courses cc
                          JOIN courses c ON cc.course_id = c.course_id
                          WHERE cc.student_id = $student_id";
$completed_courses_result = $conn->query($completed_courses_sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Hồ Sơ</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f5dc; /* Màu nền nâu vàng nhạt */
        }
        .container-sm {
            max-width: 600px; /* Giới hạn chiều rộng */
            background-color: #fff8dc; /* Màu nền trắng ngà */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 20px auto; /* Canh giữa */
        }
        .navbar {
            background-color: #8b4513; /* Màu nâu sẫm */
        }
        .navbar-brand {
            color: #fff; /* Màu chữ trắng */
        }
        .navbar-brand:hover {
            color: #f5f5dc; /* Màu chữ nâu vàng nhạt khi hover */
        }
        .btn-primary {
            background-color: #8b4513; /* Màu nâu sẫm */
            border: none;
        }
        .btn-primary:hover {
            background-color: #a0522d; /* Màu nâu đất khi hover */
        }
        .alert {
            border-radius: 5px;
        }
        .list-group-item {
            background-color: #fff8dc; /* Màu nền trắng ngà */
        }
        .card {
            background-color: #fff8dc; /* Màu nền trắng ngà */
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">Hệ Thống Đăng Ký Học</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="main.php">Trang Chủ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php">Đăng ký môn học</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">Hồ Sơ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Đăng Xuất</a>
            </li>
        </ul>
    </div>
</nav>

<div class="container-sm mt-4">
    <h2 class="text-center">Hồ Sơ Sinh Viên</h2>
    <div class="card mt-4">
        <div class="card-body">
            <h5 class="card-title">Thông Tin Cá Nhân</h5>
            <p class="card-text"><strong>Tên:</strong> <?php echo $student_info['student_name']; ?></p>
            <!-- Hiển thị thêm các thông tin khác nếu cần -->
        </div>
    </div>

    <h4 class="mt-4">Các Môn Học Đã Hoàn Thành:</h4>
    <ul class="list-group mt-3">
        <?php while ($row = $completed_courses_result->fetch_assoc()): ?>
            <li class="list-group-item"><?php echo $row['course_name']; ?></li>
        <?php endwhile; ?>
    </ul>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

<?php
$conn->close();
?>
